public class DemoPizzas
{
public static void main(String[] args)
{
     DeliveryPizza Pizza = new DeliveryPizza("sausage and onion",14.99,"Adam Street,USA");
     Pizza.display();//display pizza details
}
}