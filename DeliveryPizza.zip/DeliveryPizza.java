public class DeliveryPizza extends Pizza
{
private double deliveryFee;
private String address;
public DeliveryPizza(String description,double price,String address)
{
    super(description, price);//calls super class constructor
    if(price>15){
    this.deliveryFee=3;
    }else{
    this.deliveryFee=5;
    }
this.address=address;
}
public void display(){
    super.display();
    System.out.println("Delivery Fee: " + deliveryFee + " Address: " + address);

   }
}
