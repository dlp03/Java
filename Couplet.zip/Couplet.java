public class Couplet extends Poem{
    private static final int LINES=2;
    public Couplet(String title)
    {
        super(title,LINES);
    }
}