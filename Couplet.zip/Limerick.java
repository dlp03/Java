public class Limerick extends Poem{
    private static final int LINES=5;
    public Limerick(String title)
    {
        super(title,LINES);
    }
}